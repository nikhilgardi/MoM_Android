package com.mmpl.app;

public class GlobalVariables {

	   
	    public static String AccessId = "Test";
        
	    public static String WalletBalance = "";

	    public static String Transvaltype = "1";
	   
	    public static String OperatorIDBillPay = "3";
	  
	
}
