package com.mmpl.app.model;

import java.io.InputStream;

import org.json.JSONObject;

public class DataEx {
	InputStream _in;
	
	public DataEx(InputStream in){
		this._in = in;
	}
	
}
